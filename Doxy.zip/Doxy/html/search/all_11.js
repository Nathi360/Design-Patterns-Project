var searchData=
[
  ['_7emap',['~Map',['../class_map.html#aa403fbe09394ccf39747588f5168e3b2',1,'Map']]],
  ['_7eunit',['~Unit',['../class_unit.html#a6353fc4c0a329997ad4abcf0dcb4eb27',1,'Unit']]]
];

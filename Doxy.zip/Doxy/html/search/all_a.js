var searchData=
[
  ['notify',['notify',['../class_game.html#a9a57d754f4c6dfa34f34ac003eab6ac2',1,'Game::notify()'],['../class_rumble.html#a2579cb1f9257a251be8645bb26e8073c',1,'Rumble::notify()']]]
];

var searchData=
[
  ['mage',['Mage',['../class_mage.html',1,'']]],
  ['magic',['Magic',['../class_magic.html',1,'']]],
  ['map',['Map',['../class_map.html',1,'']]]
];

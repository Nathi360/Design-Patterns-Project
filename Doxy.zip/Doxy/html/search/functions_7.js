var searchData=
[
  ['handledamage',['handleDamage',['../class_handler.html#a8d1c54ce497a2def75b1ce449100c0d1',1,'Handler::handleDamage()'],['../classsub_handler.html#ad1fbe1c3f7494ea503755705871b4c38',1,'subHandler::handleDamage()']]]
];

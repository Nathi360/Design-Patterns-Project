var searchData=
[
  ['mage',['Mage',['../class_mage.html#a9d7d4455a6fa1f8e35117e0dc301d082',1,'Mage']]],
  ['magic',['Magic',['../class_magic.html#abdd4feafe4db804bc80b11210fa4a3df',1,'Magic']]],
  ['move',['Move',['../class_map.html#af5d2cdc79ed8fb0ea8c9b8eb649a1046',1,'Map::Move(int, int, int, int)'],['../class_map.html#af5d2cdc79ed8fb0ea8c9b8eb649a1046',1,'Map::Move(int, int, int, int)']]]
];
